

<?php $__env->startSection('title', 'Sales List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <a href="<?php echo e(route('sales.create')); ?>" class="btn btn-primary">Add New Sale</a>
    <table class="table table-bordered mt-3">
        <thead>
            <tr style="text-align: center;">
                <th>SL No.</th>
                <th>Customer Name</th>
                <th>Address</th>
                <th>Customer Contact No.</th>
                <th>Product</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Discount</th>
                <th>Total Price</th>
                <th style='width: 30%'>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($sale->customer_name); ?></td>
                    <td><?php echo e($sale->address); ?></td>
                    <td><?php echo e($sale->phone_no); ?></td>
                    <td><?php echo e($sale->product->name); ?></td>
                    <td><?php echo e($sale->product->category->name); ?></td>
                    <td><?php echo e($sale->quantity); ?></td>
                    <td><?php echo e($sale->discount); ?>%</td>
                    <td><?php echo e($sale->total_price); ?></td>
                    <td style="text-align: center;">
                        <a href="<?php echo e(route('sales.edit', $sale->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('sales.destroy', $sale->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                        <a href="<?php echo e(route('sales.invoice', $sale->id)); ?>" target="_blank" class="btn btn-info btn-sm">Print Invoice</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/sales/index.blade.php ENDPATH**/ ?>