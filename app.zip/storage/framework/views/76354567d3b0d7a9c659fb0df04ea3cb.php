
<?php $__env->startSection('title', 'Sales Return List'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <a href="<?php echo e(route('sales_returns.create')); ?>" class="btn btn-primary">Add Sales Return</a>
    <table class="table table-bordered mt-3">
        <thead>
            <tr style="text-align: center;">
                <th>Sale ID</th>
                <th>Product Name</th>
                <th>Quantity Returned</th>
                <th>Total Price</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $salesReturns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="text-align: center;"><?php echo e($return->sale->id); ?></td>
                    <td><?php echo e($return->sale->product->name); ?></td>
                    <td style="text-align: center;"><?php echo e($return->quantity); ?></td>
                    <td><?php echo e($return->total_price); ?></td>
                    <td style="text-align: center;">
                        <form action="<?php echo e(route('sales_returns.destroy', $return->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/sales_returns/index.blade.php ENDPATH**/ ?>