

<?php $__env->startSection('title', 'Products List'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary mb-3">Add New Product</a>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <table class="table table-bordered mt-3">
            <thead>
                <tr style="text-align: center;">
                    <th>SL No.</th>
                    <th>Name</th>
                    <th>Code</th>
                    <th>Supplier</th>
                    <th>Category</th>
                    <th>Purchase Price</th>
                    <th>Selling Price</th>
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Check if the stock is 10 or less, if so apply the 'table-danger' class -->
                    <tr class="<?php echo e($product->stock <= 10 ? 'table-danger' : ''); ?>">
                        <td style="text-align: center;"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($product->name); ?></td>
                        <td><?php echo e($product->code); ?></td>
                        <td><?php echo e($product->supplier->name ?? 'N/A'); ?></td>
                        <td><?php echo e($product->category->name ?? 'N/A'); ?></td>
                        <td><?php echo e($product->purchase_price); ?></td>
                        <td><?php echo e($product->selling_price); ?></td>
                        <td><?php echo e($product->stock ?? 'N/A'); ?></td>
                        <td style="text-align: center;">
                            <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                            <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/products/index.blade.php ENDPATH**/ ?>