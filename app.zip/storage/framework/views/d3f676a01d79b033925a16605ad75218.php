
<?php $__env->startSection('title', 'Create Expense'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">

    <form action="<?php echo e(route('expenses.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="salaries_wages">Salaries and Wages</label>
            <input type="number" name="salaries_wages" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="rent">Rent</label>
            <input type="number" name="rent" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="utilities">Utilities</label>
            <input type="number" name="utilities" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="other_expenses">Other Expenses</label>
            <input type="number" name="other_expenses" class="form-control" required>
        </div>

        <div class="form-group">
            <label for="transportation_cost">Transportation Cost</label>
            <input type="number" name="transportation_cost" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Save Expense</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/expenses/create.blade.php ENDPATH**/ ?>