

<?php $__env->startSection('title', 'Add New Supplier'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <form action="<?php echo e(route('suppliers.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" name="name" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <textarea name="address" class="form-control"></textarea>
            </div>

            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="number" name="phone" class="form-control" required>
            </div>

            <button type="submit" class="btn btn-success">Add Supplier</button>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/suppliers/create.blade.php ENDPATH**/ ?>