

<?php $__env->startSection('title', 'Create Purchase'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <form action="<?php echo e(route('purchases.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="order_id">Order</label>
            <select id="order_id" name="order_id" class="form-control">
                <option value="">Select Order</option>
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($order->id); ?>" 
                        data-product="<?php echo e($order->product->name); ?>" 
                        data-supplier="<?php echo e($order->supplier->name); ?>" 
                        data-price="<?php echo e($order->purchase_price); ?>" 
                        data-quantity="<?php echo e($order->quantity); ?>">
                        <?php echo e('Order No ' . $order->id); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="product_name">Product</label>
            <input type="text" id="product_name" class="form-control" readonly>
        </div>
        <div class="form-group">
            <label for="supplier_name">Supplier</label>
            <input type="text" id="supplier_name" class="form-control" readonly>
        </div>
        <div class="form-group">
            <label for="purchase_price">Purchase Price</label>
            <input type="number" id="purchase_price" class="form-control" readonly>
        </div>
        <div class="form-group">
            <label for="quantity">Quantity</label>
            <input type="number" id="quantity" name="quantity" class="form-control" required readonly>
        </div>
        <div class="form-group">
            <label for="total_price">Total Price</label>
            <input type="number" id="total_price" class="form-control" readonly>
        </div>
        <div class="form-group">
            <label for="amount_given">Amount Given</label>
            <input type="number" id="amount_given" name="amount_given" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="change_returned">Change Returned</label>
            <input type="number" id="change_returned" class="form-control" readonly>
        </div>
        <button type="submit" class="btn btn-primary">Create Purchase</button>
    </form>
</div>

<script>
    document.getElementById('order_id').addEventListener('change', function () {
        const selectedOption = this.options[this.selectedIndex];
        const product = selectedOption.getAttribute('data-product');
        const supplier = selectedOption.getAttribute('data-supplier');
        const price = selectedOption.getAttribute('data-price');
        const quantity = selectedOption.getAttribute('data-quantity');

        document.getElementById('product_name').value = product;
        document.getElementById('supplier_name').value = supplier;
        document.getElementById('purchase_price').value = price;
        document.getElementById('quantity').value = quantity;

        calculateTotalPrice();
    });

    document.getElementById('amount_given').addEventListener('input', calculateChangeReturned);

    function calculateTotalPrice() {
        const quantity = document.getElementById('quantity').value;
        const price = document.getElementById('purchase_price').value;
        const totalPrice = quantity * price;

        document.getElementById('total_price').value = totalPrice;
    }

    function calculateChangeReturned() {
        const totalPrice = document.getElementById('total_price').value;
        const amountGiven = document.getElementById('amount_given').value;
        const changeReturned = amountGiven - totalPrice;

        document.getElementById('change_returned').value = changeReturned >= 0 ? changeReturned : 0;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/purchases/create.blade.php ENDPATH**/ ?>