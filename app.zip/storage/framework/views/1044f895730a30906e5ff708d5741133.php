
<?php $__env->startSection('title', 'Sales Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    <!-- Container for forms with flexbox layout -->
    <div style="display: flex; justify-content: space-between; align-items: center;">
        <!-- Form for selecting date -->
        <form action="<?php echo e(route('sales.report')); ?>" method="GET" style="margin-right: 20px;">
            <div class="form-group">
                <label for="date">Select Date:</label>
                <input type="date" id="date" name="date" value="<?php echo e($selectedDate); ?>" class="form-control" style="width: 200px;">
            </div>
            <button type="submit" class="btn btn-primary">Generate Date Report</button>
        </form>

        <!-- Form for selecting month -->
        <form action="<?php echo e(route('sales.report')); ?>" method="GET">
            <div class="form-group">
                <label for="month">Select Month:</label>
                <select id="month" name="month" class="form-control" style="width: 150px;">
                    <option value="">Select Month</option>
                    <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthOption): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($monthOption); ?>" <?php echo e($selectedMonth == $monthOption ? 'selected' : ''); ?>>
                            <?php echo e(\DateTime::createFromFormat('!m', $monthOption)->format('F')); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Generate Month Report</button>
        </form>
    </div>

    <!-- Display report data -->
    <?php if(!empty($reportData)): ?>
    <table class="table table-bordered mt-4">
        <thead>
            <tr>
                <th>Category</th>
                <th>Product Name</th>
                <th>Units Sold</th>
                <th>Unit Price</th>
                <th>Discount</th>
                <th>Total Sales</th>
                <th>Net Sales</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $reportData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($data['category']); ?></td>
                    <td><?php echo e($data['product_name']); ?></td>
                    <td><?php echo e($data['units_sold']); ?></td>
                    <td>TK <?php echo e($data['unit_price']); ?></td>
                    <td>TK <?php echo e($data['discount']); ?></td>
                    <td>TK <?php echo e($data['total_sales']); ?></td>
                    <td>TK <?php echo e($data['net_sales']); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <p class="mt-4">No sales data available for the selected date or month.</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/sales/report.blade.php ENDPATH**/ ?>