<!DOCTYPE html>
<html>
<head>
    <title>Invoice</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .invoice-container { max-width: 800px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; }
        .header, .footer { text-align: center; margin-bottom: 20px; }
        .details { margin-bottom: 20px; }
        .details table { width: 100%; border-collapse: collapse; }
        .details table, .details th, .details td { border: 1px solid #ddd; }
        .details th, .details td { padding: 10px; text-align: left; }
        .total { text-align: right; font-weight: bold; }
    </style>
</head>

<body>
    <div class="invoice-container">
        <div class="header">
            <h1>Invoice</h1>
        </div>

        <div class="details">
            <p><strong>Supplier Name:</strong> <?php echo e($purchase->order->supplier->name); ?></p>
            <p><strong>Order:</strong> <?php echo e('Order No ' . $purchase->order->id); ?></p>
            <p><strong>Product:</strong> <?php echo e($purchase->order->product->name); ?></p>
            <p><strong>Purchase Price:</strong> <?php echo e($purchase->order->purchase_price); ?></p>
            <p><strong>Quantity:</strong> <?php echo e($purchase->quantity); ?></p>
            <p><strong>Total Price:</strong> <?php echo e($purchase->total_price); ?></p>
            <p><strong>Amount Given:</strong> <?php echo e($purchase->amount_given); ?></p>
            <p><strong>Change Returned:</strong> <?php echo e($purchase->change_returned); ?></p>
        </div>

        <div class="footer" style="text-align: center; margin-top: 20px;">
            <button onclick="window.print()" class="btn btn-primary">Print Invoice</button>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pos3\resources\views/purchases/invoice.blade.php ENDPATH**/ ?>