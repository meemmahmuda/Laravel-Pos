

<?php $__env->startSection('title', 'Orders List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <a href="<?php echo e(route('orders.create')); ?>" class="btn btn-primary">Add New Order</a>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>SL No.</th>
                <th>Product</th>
                <th>Supplier</th>
                <th>Quantity</th>
                <th>Purchase Price</th>
                <th>Total Price</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e('Order No ' . $loop->iteration); ?></td>
                    <td><?php echo e($order->product->name); ?></td>
                    <td><?php echo e($order->supplier->name); ?></td>
                    <td><?php echo e($order->quantity); ?></td>
                    <td><?php echo e($order->purchase_price); ?></td>
                    <td><?php echo e($order->total_price); ?></td>
                    <td>
                        <a href="<?php echo e(route('orders.edit', $order->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('orders.destroy', $order->id)); ?>" method="POST" style="display:inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/orders/index.blade.php ENDPATH**/ ?>