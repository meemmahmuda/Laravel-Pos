
<?php $__env->startSection('title', 'Income Statement'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Date</th>
                <th>Purchase Amount (TK)</th>
                <th>Sales Amount (TK)</th>
                <th>Profit/Loss (TK)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $incomeStatement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $statement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($statement['date']); ?></td>
                    <td><?php echo e(number_format($statement['purchase_amount'], 2)); ?></td>
                    <td><?php echo e(number_format($statement['sales_amount'], 2)); ?></td>
                    <td><?php echo e(number_format($statement['profit_or_loss'], 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4">No transactions available.</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr>
                <th colspan="3">Total Profit/Loss</th>
                <th><?php echo e(number_format($totalProfitOrLoss, 2)); ?></th>
            </tr>
        </tfoot>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pos3\resources\views/income_statement/index.blade.php ENDPATH**/ ?>